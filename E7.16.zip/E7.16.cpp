// Author: Zuhayer Tashin
// Course: CSCI-135
// Instructor: Tong Yi
// Assignment: HW E7.16
// 
// */

#include <iostream>
#include <cmath>

using namespace std;

struct Point {
    double x;
    double y;
};

double distance(Point a, Point b) {
    double dx = a.x - b.x;
    double dy = a.y - b.y;
    return sqrt(dx*dx + dy*dy);
}

int main() {
    Point p1, p2;
    cout << "Enter x and y coordinates of point 1: ";
    cin >> p1.x >> p1.y;
    cout << "Enter x and y coordinates of point 2: ";
    cin >> p2.x >> p2.y;
    double dist = distance(p1, p2);
    cout << "Distance between the points: " << dist << endl;
    return 0;
}
